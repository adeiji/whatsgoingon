//
//  DECameraButton.h
//  whatsgoinon
//
//  Created by adeiji on 9/9/14.
//  Copyright (c) 2014 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DECameraButton : UIButton

typedef enum {
    LARGE = 0,
    SMALL = 1
} ButtonType;


@end
