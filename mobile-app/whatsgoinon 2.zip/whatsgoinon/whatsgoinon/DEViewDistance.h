//
//  DEViewDistance.h
//  whatsgoinon
//
//  Created by adeiji on 9/10/14.
//  Copyright (c) 2014 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DEViewDistance : UIView

@end
