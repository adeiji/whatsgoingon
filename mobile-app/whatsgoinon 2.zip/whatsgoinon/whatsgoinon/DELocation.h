//
//  DELocation.h
//  whatsgoinon
//
//  Created by adeiji on 1/13/15.
//  Copyright (c) 2015 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DELocation : UIView

@end
