//
//  DEWelcomeEventView.h
//  whatsgoinon
//
//  Created by adeiji on 2/9/15.
//  Copyright (c) 2015 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DEWelcomeEventView : UIView

@property (weak, nonatomic) IBOutlet UIButton *btnStart;

@end
