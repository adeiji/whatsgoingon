//
//  DEAmbassadorFlag.m
//  whatsgoinon
//
//  Created by adeiji on 11/17/14.
//  Copyright (c) 2014 adeiji. All rights reserved.
//

#import "DEAmbassadorFlag.h"


@implementation DEAmbassadorFlag


- (void)drawRect:(CGRect)rect {
    [HPStyleKit drawAmbassadorFlagInRect:rect];
}


@end
