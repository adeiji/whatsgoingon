//
//  DEPromptForEpicEvents.m
//  whatsgoinon
//
//  Created by adeiji on 1/7/15.
//  Copyright (c) 2015 adeiji. All rights reserved.
//

#import "DEPromptForEpicEvents.h"

@implementation DEPromptForEpicEvents

- (void) editButtons {
    [[_btnNoThanks layer] setCornerRadius:BUTTON_CORNER_RADIUS];
    [[_btnSure layer] setCornerRadius:BUTTON_CORNER_RADIUS];
}


@end
