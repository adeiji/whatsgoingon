//
//  DEFinishedPostingView.h
//  whatsgoinon
//
//  Created by adeiji on 1/7/15.
//  Copyright (c) 2015 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DEFinishedPostingView : UIView

@property (weak, nonatomic) IBOutlet UILabel *lblParagraphOne;
@property (weak, nonatomic) IBOutlet UILabel *lblParagraphTwo;

@end
