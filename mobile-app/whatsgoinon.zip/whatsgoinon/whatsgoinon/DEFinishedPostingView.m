//
//  DEFinishedPostingView.m
//  whatsgoinon
//
//  Created by adeiji on 1/7/15.
//  Copyright (c) 2015 adeiji. All rights reserved.
//

#import "DEFinishedPostingView.h"

@implementation DEFinishedPostingView


@end
