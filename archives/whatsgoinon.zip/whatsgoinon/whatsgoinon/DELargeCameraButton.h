//
//  DELargeCameraButton.h
//  whatsgoinon
//
//  Created by adeiji on 9/11/14.
//  Copyright (c) 2014 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPStyleKit.h"

@interface DELargeCameraButton : UIButton

@property BOOL noProfileImage;

@end
