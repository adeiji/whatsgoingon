//
//  DEAmbassadorFlag.h
//  whatsgoinon
//
//  Created by adeiji on 11/17/14.
//  Copyright (c) 2014 adeiji. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPStyleKit.h"

@interface DEAmbassadorFlag : UIView

@end
